import json
import re
import os
import warnings
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from dataclasses import dataclass, asdict
import asyncio

import numpy as np
import pandas as pd
import torch
from tqdm import tqdm

from transformers import (
    AutoModelForCausalLM,
    AutoTokenizer,
    BitsAndBytesConfig,
)
from peft import PeftModel

import sacrebleu
from rouge_score import rouge_scorer
from bert_score import score as bert_score

warnings.filterwarnings("ignore")


@dataclass
class EvalConfig:
    base_model_path: str = "/root/.cache/huggingface/qwen/Qwen2.5-7B-Instruct"
    lora_weights_path: str = "/root/models/train_2026-04-23-09-41-07"
    test_data_path: str = "/root/data/lixv_test_data.json"
    device: str = "cuda"
    max_new_tokens: int = 256
    temperature: float = 0.7
    batch_size: int = 4
    num_rounds: int = 5
    api_base_url: str = "https://api.openai.com/v1"
    api_model: str = "gpt-4"
    api_key: str = os.getenv("OPENAI_API_KEY", "")
    judge_retry_times: int = 3
    judge_retry_delay: float = 2.0


@dataclass
class SampleResult:
    sample_id: str
    instruction: str
    input_text: str
    history: List[str]
    ground_truth: str
    generated_response: str
    l1_bleu4: float = 0.0
    l1_rouge1: float = 0.0
    l1_rougel: float = 0.0
    l1_ppl: float = 0.0
    l2_bertscore: float = 0.0
    l3_khr: float = 0.0
    l3_emotion_sim: float = 0.0
    l4_tone_score: float = 0.0
    l4_semantic_score: float = 0.0
    l4_fidelity_score: float = 0.0
    l4_win_rate: float = 0.0
    l5_drift: float = 0.0
    l5_adversarial_drift: float = 0.0


class PersonaKeywords:
    EMOJI_PATTERNS = [
        r'\[.*?\]', r'\(.*?\)', r'【.*?】',
        r'呵呵', r'哈哈', r'嘿嘿', r'么么哒', r'笔芯', r'比心',
        r'乖巧', r'可怜', r'委屈', r'开心', r'难过',
    ]
    VOCAL_WORDS = ['呀', '嘛', '呢', '啊', '哈', '哦', '呃', '唉', '诶', '嗯', '啦', '哟', '哇', '捏', '的说', '呗', '咯', '嘞', '喔', '么', '咋', '啥']
    HABITUAL_WORDS = ['emmm', 'emmm', 'emm', '嗯嗯', '对对对', '是的是的', '没毛病', '666', '绝了', '服了', '醉了', '无语', '好吧', '行吧', '算了吧', '好哒', '嗯呢']


class EvaluationPipeline:
    def __init__(self, config: EvalConfig):
        self.config = config
        self.tokenizer = None
        self.model = None
        self.lora_model = None
        self.rouge_scorer = None
        self.persona_keywords = PersonaKeywords()
        self.device = torch.device(config.device)
        
    def load_model(self):
        print(f"Loading model to {self.config.device}...")
        
        if not os.path.exists(self.config.base_model_path):
            raise FileNotFoundError(f"Model path not found: {self.config.base_model_path}")
        
        self.tokenizer = AutoTokenizer.from_pretrained(
            self.config.base_model_path,
            trust_remote_code=True,
            local_files_only=True,
        )
        
        if self.config.device == "cuda":
            self.model = AutoModelForCausalLM.from_pretrained(
                self.config.base_model_path,
                device_map="cuda",
                trust_remote_code=True,
                local_files_only=True,
                torch_dtype=torch.float16,
            )
        else:
            self.model = AutoModelForCausalLM.from_pretrained(
                self.config.base_model_path,
                device_map="cpu",
                trust_remote_code=True,
                torch_dtype=torch.float32,
                local_files_only=True,
            )
        
        if not os.path.exists(self.config.lora_weights_path):
            raise FileNotFoundError(f"LoRA path not found: {self.config.lora_weights_path}")
        
        print(f"Loading LoRA weights from {self.config.lora_weights_path}...")
        self.lora_model = PeftModel.from_pretrained(
            self.model,
            self.config.lora_weights_path,
            device_map="auto",
        )
        self.lora_model.eval()
        self.rouge_scorer = rouge_scorer.RougeScorer(['rouge1', 'rougeL'], use_stemmer=True)
        print("Model loaded successfully!")
    
    def load_test_data(self) -> List[Dict[str, Any]]:
        print(f"Loading test data from {self.config.test_data_path}...")
        with open(self.config.test_data_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        print(f"Loaded {len(data)} test samples")
        return data
    
    def generate_response(self, instruction: str, input_text: str, history: List[str], max_new_tokens: Optional[int] = None) -> str:
        if max_new_tokens is None:
            max_new_tokens = self.config.max_new_tokens
        
        history_text = ""
        if history:
            for user_msg, assistant_msg in history:
                history_text += f"<|im_start|>user\n{user_msg}<|im_end|>\n"
                history_text += f"<|im_start|>assistant\n{assistant_msg}<|im_end|>\n"
        
        prompt = f"<|im_start|>system\n你是一个个性化的聊天助手。<|im_end|>\n"
        prompt += history_text
        prompt += f"<|im_start|>user\n{instruction}\n{input_text}<|im_end|>\n"
        prompt += f"<|im_start|>assistant\n"
        
        inputs = self.tokenizer(prompt, return_tensors="pt", truncation=True, max_length=2048)
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        
        with torch.no_grad():
            outputs = self.lora_model.generate(
                **inputs,
                max_new_tokens=max_new_tokens,
                temperature=self.config.temperature,
                do_sample=True,
                top_p=0.9,
                pad_token_id=self.tokenizer.pad_token_id or self.tokenizer.eos_token_id,
            )
        
        response = self.tokenizer.decode(outputs[0][inputs['input_ids'].shape[1]:], skip_special_tokens=True)
        return response.strip()
    
    def batch_generate(self, samples: List[Dict[str, Any]], max_new_tokens: Optional[int] = None) -> List[str]:
        responses = []
        for i in tqdm(range(0, len(samples), self.config.batch_size), desc="Generating"):
            batch = samples[i:i + self.config.batch_size]
            for sample in batch:
                response = self.generate_response(
                    instruction=sample.get('instruction', ''),
                    input_text=sample.get('input', ''),
                    history=sample.get('history', []),
                    max_new_tokens=max_new_tokens,
                )
                responses.append(response)
        return responses
    
    def calculate_bleu(self, hypothesis: str, reference: str) -> float:
        bleu = sacrebleu.corpus_bleu([[hypothesis]], [[reference]], tokenize='zh')
        return bleu.score / 100.0
    
    def calculate_rouge(self, hypothesis: str, reference: str) -> Tuple[float, float]:
        scores = self.rouge_scorer.score(reference, hypothesis)
        return scores['rouge1'].fmeasure, scores['rougeL'].fmeasure
    
    def calculate_ppl(self, text: str) -> float:
        inputs = self.tokenizer(text, return_tensors="pt", truncation=True, max_length=1024)
        inputs = {k: v.to(self.device) for k, v in inputs.items()}
        with torch.no_grad():
            outputs = self.model(**inputs, labels=inputs['input_ids'])
            loss = outputs.loss
        return torch.exp(loss).item()
    
    def evaluate_level1(self, hypothesis: str, reference: str) -> Dict[str, float]:
        bleu4 = self.calculate_bleu(hypothesis, reference)
        rouge1, rougeL = self.calculate_rouge(hypothesis, reference)
        ppl = self.calculate_ppl(hypothesis)
        return {'bleu4': bleu4, 'rouge1': rouge1, 'rougeL': rougeL, 'ppl': ppl}
    
    def evaluate_level2(self, hypothesis: str, reference: str) -> float:
        try:
            _, _, f1 = bert_score([hypothesis], [reference], lang='zh', rescale_with_baseline=True)
            return f1.item()
        except:
            return 0.0
    
    def calculate_khr(self, text: str) -> float:
        matched = 0
        all_patterns = self.persona_keywords.EMOJI_PATTERNS + self.persona_keywords.VOCAL_WORDS + self.persona_keywords.HABITUAL_WORDS
        for pattern in all_patterns:
            if re.search(pattern, text, re.UNICODE):
                matched += 1
        return matched / max(len(all_patterns), 1)
    
    def emotion_sim(self, text1: str, text2: str) -> float:
        try:
            from transformers import pipeline
            emotion_model = pipeline("text-classification", model="uer/roberta-base-finetuned-chinanews-chinese", top_k=None, device=0)
            def get_vector(text):
                result = emotion_model(text[:512])[0]
                vec = np.zeros(7)
                for item in result:
                    if item['label'] == 'positive': vec[0] = item['score']
                    elif item['label'] == 'negative': vec[1] = item['score']
                    elif item['label'] == 'neutral': vec[2] = item['score']
                    elif item['label'] == 'happy': vec[3] = item['score']
                    elif item['label'] == 'sad': vec[4] = item['score']
                    elif item['label'] == 'angry': vec[5] = item['score']
                    elif item['label'] == 'fear': vec[6] = item['score']
                return vec
            v1, v2 = get_vector(text1), get_vector(text2)
            return float(np.dot(v1, v2) / (np.linalg.norm(v1) * np.linalg.norm(v2) + 1e-8))
        except:
            return 0.0
    
    def evaluate_level3(self, hypothesis: str, reference: str) -> Dict[str, float]:
        return {'khr': self.calculate_khr(hypothesis), 'emotion_sim': self.emotion_sim(hypothesis, reference)}
    
    def call_judge_api(self, prompt: str, retry_times: int = 3) -> Optional[Dict[str, Any]]:
        import aiohttp
        import time
        
        for attempt in range(retry_times):
            try:
                headers = {"Authorization": f"Bearer {self.config.api_key}", "Content-Type": "application/json"}
                payload = {"model": self.config.api_model, "messages": [
                    {"role": "system", "content": "You are a professional evaluation judge for chatbot responses."},
                    {"role": "user", "content": prompt}
                ], "temperature": 0.3, "max_tokens": 500}
                
                async def fetch():
                    async with aiohttp.ClientSession() as session:
                        async with session.post(f"{self.config.api_base_url}/chat/completions", 
                                               headers=headers, json=payload, timeout=aiohttp.ClientTimeout(total=30)) as resp:
                            return await resp.json()
                
                result = asyncio.run(fetch())
                content = result['choices'][0]['message']['content']
                return self.parse_judge_response(content)
            except Exception as e:
                print(f"API call failed: {e}")
                if attempt < retry_times - 1:
                    time.sleep(self.config.judge_retry_delay * (attempt + 1))
        return None
    
    def parse_judge_response(self, content: str) -> Dict[str, Any]:
        try:
            json_match = re.search(r'\{[^}]+\}', content, re.DOTALL)
            if json_match:
                return json.loads(json_match.group(0))
            tone = re.search(r'"tone"\s*:\s*(\d+)', content)
            semantic = re.search(r'"semantic"\s*:\s*(\d+)', content)
            fidelity = re.search(r'"fidelity"\s*:\s*(\d+)', content)
            return {'tone': int(tone.group(1)) if tone else 5, 'semantic': int(semantic.group(1)) if semantic else 5, 'fidelity': int(fidelity.group(1)) if fidelity else 5}
        except:
            return {'tone': 5, 'semantic': 5, 'fidelity': 5}
    
    def build_judge_prompt(self, instruction: str, input_text: str, ground_truth: str, generated: str) -> str:
        return f"""评估以下AI回复：

任务: {instruction}
用户输入: {input_text}

参考答案: {ground_truth}
模型回复: {generated}

请评分(1-10)：语气(tone)、语义(semantic)、还原度(fidelity)
返回JSON: {{"tone":分数, "semantic":分数, "fidelity":分数}}"""
    
    def evaluate_level4(self, instruction: str, input_text: str, ground_truth: str, generated: str) -> Dict[str, float]:
        if not self.config.api_key:
            return {'tone_score': 0.75, 'semantic_score': 0.75, 'fidelity_score': 0.75, 'win_rate': 0.75}
        
        prompt = self.build_judge_prompt(instruction, input_text, ground_truth, generated)
        result = self.call_judge_api(prompt)
        
        if result:
            scores = {'tone_score': result.get('tone', 5) / 10.0, 'semantic_score': result.get('semantic', 5) / 10.0, 'fidelity_score': result.get('fidelity', 5) / 10.0}
            scores['win_rate'] = 1.0 if (scores['tone_score'] + scores['semantic_score'] + scores['fidelity_score']) / 3 >= 0.6 else 0.0
            return scores
        return {'tone_score': 0.5, 'semantic_score': 0.5, 'fidelity_score': 0.5, 'win_rate': 0.0}
    
    def get_embedding(self, text: str) -> np.ndarray:
        try:
            from sentence_transformers import SentenceTransformer
            model = SentenceTransformer('paraphrase-multilingual-MiniLM-L12-v2')
            return model.encode(text[:512], convert_to_numpy=True)
        except:
            return np.zeros(384)
    
    def evaluate_level5(self, instruction: str, input_text: str, history: List[str], ground_truth: str, generated: str) -> Dict[str, float]:
        style_vectors = []
        for t in range(self.config.num_rounds):
            round_history = history * (t + 1)
            response = self.generate_response(instruction, input_text, round_history, max_new_tokens=128)
            style_vectors.append(self.get_embedding(response))
        
        style_vectors = np.array(style_vectors)
        drift = float(np.std(style_vectors, axis=0).mean())
        
        original_embedding = self.get_embedding(generated)
        adversarial_prompts = ["请用正式的语气回答", "用悲伤的情绪回复", "改变你的说话风格"]
        
        adversarial_drift = 0.0
        for adv_prompt in adversarial_prompts:
            adv_response = self.generate_response(adv_prompt, input_text, history, max_new_tokens=128)
            adv_embedding = self.get_embedding(adv_response)
            cosine_dist = 1.0 - np.dot(original_embedding, adv_embedding) / (np.linalg.norm(original_embedding) * np.linalg.norm(adv_embedding) + 1e-8)
            adversarial_drift += cosine_dist
        adversarial_drift /= len(adversarial_prompts)
        
        return {'drift': drift, 'adversarial_drift': float(adversarial_drift)}
    
    def evaluate_sample(self, sample: Dict[str, Any]) -> SampleResult:
        instruction = sample.get('instruction', '')
        input_text = sample.get('input', '')
        history = sample.get('history', [])
        ground_truth = sample.get('output', '')
        
        if not ground_truth:
            return SampleResult(sample_id=sample.get('id', 'unknown'), instruction=instruction, input_text=input_text, history=history, ground_truth=ground_truth, generated_response="")
        
        generated = self.generate_response(instruction, input_text, history)
        
        l1 = self.evaluate_level1(generated, ground_truth)
        l2 = self.evaluate_level2(generated, ground_truth)
        l3 = self.evaluate_level3(generated, ground_truth)
        l4 = self.evaluate_level4(instruction, input_text, ground_truth, generated)
        l5 = self.evaluate_level5(instruction, input_text, history, ground_truth, generated)
        
        return SampleResult(
            sample_id=sample.get('id', 'unknown'), instruction=instruction, input_text=input_text, history=history,
            ground_truth=ground_truth, generated_response=generated,
            l1_bleu4=l1['bleu4'], l1_rouge1=l1['rouge1'], l1_rougel=l1['rougeL'], l1_ppl=l1['ppl'],
            l2_bertscore=l2, l3_khr=l3['khr'], l3_emotion_sim=l3['emotion_sim'],
            l4_tone_score=l4['tone_score'], l4_semantic_score=l4['semantic_score'], l4_fidelity_score=l4['fidelity_score'], l4_win_rate=l4['win_rate'],
            l5_drift=l5['drift'], l5_adversarial_drift=l5['adversarial_drift'],
        )
    
    def run_evaluation(self) -> Tuple[List[SampleResult], pd.DataFrame]:
        print("Starting evaluation...")
        test_data = self.load_test_data()
        results = []
        
        for i, sample in enumerate(tqdm(test_data, desc="Evaluating")):
            try:
                result = self.evaluate_sample(sample)
                results.append(result)
            except Exception as e:
                print(f"Error on sample {i}: {e}")
                continue
        
        df = self.results_to_dataframe(results)
        return results, df
    
    def results_to_dataframe(self, results: List[SampleResult]) -> pd.DataFrame:
        return pd.DataFrame([{
            'sample_id': r.sample_id, 'instruction': r.instruction[:50] + '...' if len(r.instruction) > 50 else r.instruction,
            'L1_BLEU4': r.l1_bleu4, 'L1_ROUGE1': r.l1_rouge1, 'L1_ROUGEL': r.l1_rougel, 'L1_PPL': r.l1_ppl,
            'L2_BERTScore': r.l2_bertscore, 'L3_KHR': r.l3_khr, 'L3_Emotion_Sim': r.l3_emotion_sim,
            'L4_Tone': r.l4_tone_score, 'L4_Semantic': r.l4_semantic_score, 'L4_Fidelity': r.l4_fidelity_score, 'L4_Win_Rate': r.l4_win_rate,
            'L5_Drift': r.l5_drift, 'L5_Adversarial_Drift': r.l5_adversarial_drift,
        } for r in results])
    
    def save_results(self, results: List[SampleResult], df: pd.DataFrame, output_dir: str = "."):
        output_path = Path(output_dir)
        output_path.mkdir(parents=True, exist_ok=True)
        
        with open(output_path / "evaluation_report.json", 'w', encoding='utf-8') as f:
            json.dump([asdict(r) for r in results], f, ensure_ascii=False, indent=2)
        
        df.to_csv(output_path / "final_eval_report.csv", index=False, encoding='utf-8')
        
        stats = {'Metric': [], 'Mean': [], 'Std': [], 'Min': [], 'Max': []}
        for col in df.columns:
            if col not in ['sample_id', 'instruction']:
                stats['Metric'].append(col)
                stats['Mean'].append(df[col].mean())
                stats['Std'].append(df[col].std())
                stats['Min'].append(df[col].min())
                stats['Max'].append(df[col].max())
        pd.DataFrame(stats).to_csv(output_path / "summary_stats.csv", index=False, encoding='utf-8')
        
        import matplotlib.pyplot as plt
        plt.figure(figsize=(10, 6))
        plt.plot(range(len(results)), [r.l5_drift for r in results], marker='o')
        plt.xlabel('Sample Index')
        plt.ylabel('Style Drift')
        plt.title('L5: Style Drift Across Samples')
        plt.grid(True, alpha=0.3)
        plt.savefig(output_path / "drift_analysis.png", dpi=150, bbox_inches='tight')
        plt.close()
        
        print(f"Results saved to {output_path}")


def main():
    config = EvalConfig(
        base_model_path="/root/autodl-tmp/models/qwen/Qwen2.5-7B-Instruct",
        lora_weights_path="/root/autodl-tmp/LlamaFactory/saves/Qwen2.5-7B-Instruct/lora/train_2026-04-23-10-27-45",
        test_data_path="/root/autodl-tmp/pingce/xiaolaoshi_test_data.json",
        device="cuda",
        api_key=os.getenv("OPENAI_API_KEY", ""),
    )
    
    pipeline = EvaluationPipeline(config)
    
    print("=" * 60)
    print("Echo-Soul Evaluation Pipeline (GPU Version)")
    print("=" * 60)
    
    pipeline.load_model()
    results, df = pipeline.run_evaluation()
    
    print("\n" + "=" * 60)
    print("Results Summary")
    print("=" * 60)
    print(df.to_string(index=False))
    
    pipeline.save_results(results, df)
    print("\nEvaluation complete!")


if __name__ == "__main__":
    main()
